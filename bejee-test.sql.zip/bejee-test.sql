-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 08 2021 г., 00:02
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `bejee-test`
--

-- --------------------------------------------------------

--
-- Структура таблицы `tasks`
--

CREATE TABLE `tasks` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `task` text NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tasks`
--

INSERT INTO `tasks` (`id`, `name`, `email`, `task`, `status`) VALUES
(1, 'Павел222222222222233', 'kinobasa777@gmail.com', 'Bootstrap включает в себя шесть предустановленных стилей кнопок, каждая из которых обслуживает свое собственное смысловое назначение.', 1),
(2, 'Игорь Иванович2', 'user38@gmail.com', 'Числовые строки могут содержать любое количество цифр, знаки (например, + или —), десятичные дроби и экспоненту. Следовательно, + 234.5e6 является допустимой числовой строкой. Двоичная и шестнадцатеричная запись не допускаются.', 1),
(4, 'Елена555', 'mozer_pavel@mail.ru', 'Можем работать как напрямую с системами бронирования вроде Сирены, Амадеуса или Галилео, так и с API более высокого уровня, такими как Aviasales, Booking, Sletat.ru, AirBNB.', 1),
(9, '55555555555', 'b_d_92@mail.ru', 'asdasdasd', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `params` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `hash` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `dop_info` text NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `role`, `login`, `password`, `params`, `hash`, `email`, `name`, `phone`, `dop_info`, `image`) VALUES
(1, 'admin', 'admin', '6df1a592ef6ed7ec2794061ae5bf808d', '', '', 'itdeveloper0@gmail.com', 'Павел33', '+375 (32)44444444445555777', 'обо мне ', 'e096b51304f004d025a5e5ab110c4f7e.jpg'),
(2, 'user', 'user1', '8926748f070b634328301c1e4a26277b', NULL, '', 'user1@gmail.com', 'Павел', '+38(333) 333-33-33', 'sdfsdfsdffds', ''),
(3, 'user', 'user2', '8ed794474090725a6843b1a6eda9b193', NULL, NULL, 'user2@gmail.com', 'Павел333', '44444', '', ''),
(4, 'user', 'user3', '0433d5b3739776694ca6b66be7a92ea4', NULL, '', 'user3@gmail.com', 'Павел555', '555', 'фывфыв', '7b5110ebd7389ebe62a484dff626d716.png'),
(5, 'user', 'user4', '31152ecbf07616f20b24904f542231c3', NULL, NULL, 'user4@gmail.com', 'Павел', '111', '', ''),
(6, 'user', 'user5', '61c21cb29dfd561cbc191f59c72db604', NULL, NULL, 'user5@femida24.kz', 'user5', '+38(333) 333-33-33', '', ''),
(7, 'user', 'user6', 'f5e77b71a09ef1ea93e511bfe7800072', NULL, NULL, 'super_admin@femida24.kz', 'Павел', '2', '', ''),
(8, 'user', 'user7', '98139f0132e444e0eff81de7a8219445', NULL, NULL, 'user7@gmail.com', 'Павел', '+38(333) 333-33-33', '', ''),
(9, 'user', 'user8', '0fd8113f8d6b6b5079a7520050cc9c44', NULL, NULL, 'user8@femida24.kz', 'Павел', '77777', '', ''),
(10, 'user', 'user11', '1d69fad1b1cb955fb3a5b6c20258224d', NULL, '', 'user11@femida24.kz', 'Павел', '111111111111111', '', ''),
(11, 'user', 'user133', 'f608d542130245ea0be09700aa60c400', NULL, '', 'user133@gmail.com', 'Павел', '+38(333) 333-33-33', 'asdasdasdasdasdasd', ''),
(12, 'user', 'user11555', 'ad2281f3a53a2efdee8d67877ec5afff', NULL, '', 'user11555@gmail.com', 'Павел', '+38(333) 333-33-33', '', ''),
(13, 'user', 'user13', 'e469464b2cc39fcb210f4b4ade36e064', NULL, NULL, 'user13@gmail.com', 'user13', '', '', ''),
(14, 'user', 'user14', '1fda3f9681c469d99ac84972f3008600', NULL, NULL, 'user14@gmail.com', '', '', '', '');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
